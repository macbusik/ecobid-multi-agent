var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_b89b5a39._.js")
R.c("server/chunks/[root-of-the-server]__f25e1360._.js")
R.c("server/chunks/frontend__next-internal_server_app_favicon_ico_route_actions_7d672445.js")
R.m(44476)
module.exports=R.m(44476).exports
