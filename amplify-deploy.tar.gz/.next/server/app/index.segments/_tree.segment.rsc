:HL["/_next/static/chunks/27f75ade7097a2c5.css","style"]
0:{"buildId":"STDu1I0GAO70WBqP0Vq2H","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
