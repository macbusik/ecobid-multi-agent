globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/d0577bca46a62b96.js",
    "static/chunks/35ab86f125ccfab4.js",
    "static/chunks/6b8c38cc1ceab5fd.js",
    "static/chunks/5b4fd673f3068fda.js",
    "static/chunks/turbopack-b2f36dd9bf206066.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];