module.exports=[47481,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_items_%5Bid%5D_page_actions_52628b0d.js.map