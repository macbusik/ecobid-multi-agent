module.exports=[90645,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_items_new_page_actions_db7e3db1.js.map