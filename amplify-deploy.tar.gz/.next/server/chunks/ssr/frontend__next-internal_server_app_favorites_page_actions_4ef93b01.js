module.exports=[83109,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_favorites_page_actions_4ef93b01.js.map